﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(gss.Startup))]
namespace gss
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
